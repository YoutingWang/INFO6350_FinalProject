import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:exe8/models/posts.dart';

class DatabaseService {
  final String uid;
  DatabaseService({this.uid});

  // collection reference
  final CollectionReference itemCollection =
      Firestore.instance.collection('meinan-posts');

  Future updateUserData(String title, int price, String description,
      List<String> imageUrls) async {
    return await itemCollection.document(uid).setData({
      'title': title,
      'price': price,
      'description': description,
      'imageUrls': imageUrls
    });
  }

  //posts list from snapshot
  List<Post> _postListFormSnapshot(QuerySnapshot snapshot) {
    return snapshot.documents.map(
      (doc) {
        return Post(
          title: doc.data['title'] ?? '',
          price: doc.data['price'] ?? 0,
          description: doc.data['description'] ?? '',
          images: doc.data['imageUrls'].cast<String>() ?? [],
        );
      },
    ).toList();
  }

  // get posts stream
  Stream<List<Post>> get posts {
    return itemCollection.snapshots().map(_postListFormSnapshot);
  }
}
