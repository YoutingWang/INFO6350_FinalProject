import 'dart:async';
import 'dart:typed_data';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:exe8/shared/constants.dart';
import 'package:exe8/services/database.dart';
import 'package:provider/provider.dart';
import 'package:exe8/models/user.dart';
import 'package:multi_image_picker/multi_image_picker.dart';

class NewPost extends StatefulWidget {
  @override
  _NewPostState createState() => _NewPostState();
}

class _NewPostState extends State<NewPost> {
  final _formKey = GlobalKey<FormState>();
  List<Asset> images = List<Asset>();

  String _currentTitle;
  int _currentPrice;
  String _currentDescription;
  List<String> _imageUrls = List<String>();

  //String error;
  bool loading = false;

  void _postNewItemSnackBar(BuildContext context) {
    print('postNewItemSnackbar');
    final snackBar = SnackBar(
      content: new Text(
          "Added new post successfully! You can return to home page to check it now."),
      duration: Duration(minutes: 2),
    );
    Scaffold.of(context).showSnackBar(snackBar);
  }

  Widget buildGridView() {
    print('buildGridView');
    print(images.length == 0);
    return images.length == 0
        ? SizedBox(
            height: 20.0,
          )
        : Expanded(
            child: GridView.count(
              crossAxisCount: 3,
              mainAxisSpacing: 20,
              crossAxisSpacing: 20,
              children: List.generate(images.length, (index) {
                Asset asset = images[index];
                return AssetThumb(
                  asset: asset,
                  width: 150,
                  height: 150,
                );
              }),
            ),
          );
  }

  Future<void> _getImageList() async {
    // List<Asset> resultList = List<Asset>();
    //File image;
    print('get item list');
    try {
      var resultList = await MultiImagePicker.pickImages(
        maxImages: 4,
        enableCamera: true,
      );

      print('resultlist: ');
      print(resultList);
      print('images: ');
      print(images);

      setState(() {
        images = resultList;
      });
    } catch (e) {
      print('error!');
      print(e.toString());
    }
  }

  Future _postImage(Asset imageFile) async {
    print('postImage');
    ByteData byteData = await imageFile.getByteData();
    List<int> imageData = byteData.buffer.asUint8List();
    String fileName = DateTime.now().millisecondsSinceEpoch.toString();
    StorageReference reference = FirebaseStorage.instance.ref().child(fileName);
    StorageUploadTask uploadTask = reference.putData(imageData);
    StorageTaskSnapshot storageTaskSnapshot = await uploadTask.onComplete;
    String imageUrl = await storageTaskSnapshot.ref.getDownloadURL();

    print('url');
    print(imageUrl.toString());
    _imageUrls.add(imageUrl.toString());
  }

  @override
  Widget build(BuildContext context) {
    User user = Provider.of<User>(context);
    print('test uid');
    print(user.uid);
    return Scaffold(
      backgroundColor: Colors.blue[100],
      appBar: AppBar(
        backgroundColor: Colors.blue[400],
        elevation: 0.0,
        title: Text('Create a new post'),
      ),
      body: Builder(
        builder: (context) => Container(
          padding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 30.0),
          child: Form(
            key: _formKey,
            child: Column(
              children: <Widget>[
                SizedBox(height: 20.0),
                TextFormField(
                  decoration: textInputDecoration.copyWith(
                      hintText: 'Enter title of item'),
                  validator: (val) =>
                      val.isEmpty ? 'Title of item cannot be empty' : null,
                  onChanged: (val) {
                    setState(() => _currentTitle = val);
                  },
                ),
                SizedBox(height: 20.0),
                TextFormField(
                  decoration:
                      textInputDecoration.copyWith(hintText: 'Enter price'),
                  validator: (val) =>
                      val is int ? 'Price must be an integer' : null,
                  onChanged: (val) {
                    setState(() => _currentPrice = int.parse(val));
                  },
                ),
                SizedBox(height: 20.0),
                TextFormField(
                  decoration: textInputDecoration.copyWith(
                      hintText: 'Enter description'),
                  validator: (val) => val.isEmpty
                      ? 'Description of item cannot be empty'
                      : null,
                  onChanged: (val) {
                    setState(() => _currentDescription = val);
                  },
                ),
                SizedBox(height: 15.0),

                // Expanded(
                //   child: buildGridView(),
                // ),

                buildGridView(),

                //Button to upload images
                RaisedButton(
                  color: Colors.blue[500],
                  child: Text(
                    'Select photos',
                    style: TextStyle(color: Colors.white),
                  ),
                  onPressed: () {
                    _getImageList();
                  },
                ),

                SizedBox(height: 15.0),

                //button to upload new post
                RaisedButton(
                  color: Colors.blue[500],
                  child: Text(
                    'Post',
                    style: TextStyle(color: Colors.white),
                  ),
                  onPressed: () async {
                    if (_formKey.currentState.validate()) {
                      //add a snack bar to show user add new post successfully
                      _postNewItemSnackBar(context);
                      for (Asset a in images) {
                        await _postImage(a);
                      }

                      await DatabaseService(uid: user.uid).updateUserData(
                          _currentTitle,
                          _currentPrice,
                          _currentDescription,
                          _imageUrls);

                      // Navigator.push(
                      //   context,
                      //   MaterialPageRoute(builder: (context) => Home()),
                      // );
                    }
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
