import 'package:cached_network_image/cached_network_image.dart';
import 'package:exe8/screens/home/itemDetail.dart';
import 'package:flutter/material.dart';
import 'package:exe8/models/posts.dart';

class PostDetail extends StatelessWidget {
  final Post post;

  PostDetail({this.post});

  Widget buildGridView(context) {
    return GridView.count(
      shrinkWrap: true,
      crossAxisCount: 4,
      children: List.generate(
        post.images.length,
        (index) {
          return GestureDetector(
            child: Hero(
              tag: post.images[index],
              child: new Container(
                child: CachedNetworkImage(
                  imageUrl: post.images[index],
                  placeholder: (context, url) => new Center(
                    child: Container(
                      width: 30,
                      height: 30,
                      child: new CircularProgressIndicator(),
                    ),
                  ),
                  errorWidget: (context, url, error) => new Icon(Icons.error),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        Text(
          post.title,
          textAlign: TextAlign.left,
          style: TextStyle(fontSize: 20.0),
        ),
        SizedBox(
          height: 10.0,
        ),
        Padding(
          padding: EdgeInsets.fromLTRB(20.0, 6.0, 20.0, 0.0),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              // when images is null, here will trigger null pointer exception
              post.images == null
                  ? SizedBox(
                      height: 20.0,
                    )
                  : Flexible(child: buildGridView(context)),
            ],
          ),
        )
      ],
    );
  }
}
