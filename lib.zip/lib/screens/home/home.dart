import 'package:exe8/services/auth.dart';
import 'package:flutter/material.dart';
import 'package:exe8/services/database.dart';
import 'package:provider/provider.dart';
import 'package:exe8/screens/home/postList.dart';
import 'package:exe8/models/posts.dart';
import 'package:exe8/screens/home/newPost.dart';

class Home extends StatelessWidget {
  final AuthService _auth = AuthService();

  @override
  Widget build(BuildContext context) {
    return StreamProvider<List<Post>>.value(
      value: DatabaseService().posts,
      child: Scaffold(
        backgroundColor: Colors.blue[50],
        appBar: AppBar(
          title: Text('HyperGarageSale'),
          backgroundColor: Colors.blue[400],
          elevation: 0.0,
          actions: <Widget>[
            FlatButton.icon(
              icon: Icon(Icons.person),
              label: Text('Log Out'),
              onPressed: () async {
                await _auth.signOut();
              },
            )
          ],
        ),
        body: PostList(),
        // create a floating button to navigate the create new post page
        floatingActionButton: FloatingActionButton(
          onPressed: () {
            Navigator.push(
                context, MaterialPageRoute(builder: (context) => NewPost()));
          },
          child: Icon(Icons.navigation),
          backgroundColor: Colors.blue,
        ),
      ),
    );
  }
}
