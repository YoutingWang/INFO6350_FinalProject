import 'package:exe8/models/posts.dart';
import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';

import 'imageDetail.dart';

class ItemDetail extends StatelessWidget {
  final Post post;

  ItemDetail({this.post});

  Widget buildGridView(context) {
    return GridView.count(
      shrinkWrap: true,
      crossAxisCount: 2,
      children: List.generate(
        post.images.length,
        (index) {
          return GestureDetector(
            child: Hero(
              tag: post.images[index],
              child: new Container(
                child: CachedNetworkImage(
                  imageUrl: post.images[index],
                  placeholder: (context, url) => new Center(
                    child: Container(
                      width: 30,
                      height: 30,
                      child: new CircularProgressIndicator(),
                    ),
                  ),
                  errorWidget: (context, url, error) => new Icon(Icons.error),
                ),
              ),
            ),
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          ImageDetail(post.images[index], post.images[index])));
            },
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build

    return Scaffold(
      backgroundColor: Colors.blue[100],
      appBar: AppBar(
        backgroundColor: Colors.blue[400],
        elevation: 0.0,
        title: Text('Item Detail'),
      ),
      body: Builder(
        builder: (context) => Container(
          padding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 30.0),
          child: Column(
            children: <Widget>[
              Text(
                'Title: ' + post.title,
                style: TextStyle(fontSize: 20.0),
              ),
              SizedBox(
                height: 20.0,
              ),
              Text(
                'Price: ' + ' \$${post.price}',
                style: TextStyle(fontSize: 20.0),
              ),
              SizedBox(
                height: 20.0,
              ),
              Text(
                'Description: ' + post.description,
                style: TextStyle(fontSize: 20.0),
              ),
              SizedBox(
                height: 20.0,
              ),
              Text(
                'Show images here: ',
                style: TextStyle(fontSize: 20.0),
              ),
              post.images == null
                  ? new Text("No photo")
                  : Expanded(
                      child: buildGridView(context),
                    ),
              SizedBox(
                height: 20.0,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
