class Post {
  final String title;
  final int price;
  final String description;
  final List<String> images;

  Post({this.title, this.price, this.description, this.images});
}
